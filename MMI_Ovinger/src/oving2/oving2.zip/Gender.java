package oving2;

public enum Gender {

	MALE,
	FEMALE;
	
}
